docker run -it tvprograms /bin/bash
