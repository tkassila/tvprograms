docker rm $(docker ps -a -q)
