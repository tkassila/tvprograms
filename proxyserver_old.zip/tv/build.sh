docker build  -t tvprograms .
