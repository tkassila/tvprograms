docker stop $(docker ps -a -q)
